#include <raylib.h>
#include <iostream>
#include <vector>
#include <math.h>

struct ScreenStruct
{
    int width = 1920;
    int height = 1080;
};

ScreenStruct screen;

int main()
{
    InitWindow(screen.width, screen.height, "Raylib test");
    SetTargetFPS(120);

    while(WindowShouldClose() == false)
    {

        BeginDrawing();
        ClearBackground((Color){50, 50, 50, 255});
        DrawFPS(10, 10);

        EndDrawing();
    }

    CloseWindow();
    return 0;
}