#pragma once

//Defines a simple Transform struct
struct MTransform
{
    Vector2 pos;

    float Scale;
    float rot;
};