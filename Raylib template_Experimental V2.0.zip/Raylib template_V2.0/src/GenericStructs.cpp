#include <iostream>
#include<raylib.h>

#include "src/GenericStructs.h"

//Defines the MTransform property, based on the Transform header.
struct MTransform transform;