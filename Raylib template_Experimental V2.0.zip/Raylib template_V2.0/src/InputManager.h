# pragma once

//Defines the InputManager class
//Defines the Getaxis vector from the inputmanager.
class InputManager 
{
    public:
        static Vector2 Getaxis(float Scale);
};