#include "Game.h"

void Start()
{

}

void Update()
{
    ClearBackground((Color){50, 50, 50, 255});
    DrawFPS(10, 10);
}

void FixedUpdate(float deltaTime)
{

}